// Problem: Range Increment Queries

// You are given:
// An array of integers arr[]
// A list of queries, where each query is a pair {L, R}
// An integer d

// Task: For each query {L, R}, add d to all elements from index L to R (inclusive). After performing all queries in order, print the final state of the array.

// ✍️ Input Format
// An integer array: arr[]
// A list of queries: {L, R}
// An integer d — the increment value

// 📤 Output Format
// Print the final array after all queries are applied, space-separated.

// 🔄 Example
// Input
// arr[] = {3, 5, 4, 8, 6, 1}
// Query list: {0, 3}, {4, 5}, {1, 4}, {0, 1}, {2, 5}
// d = 2

// Output
// 7 11 10 14 12 5

import java.util.*;
public class Main{
    public static void  addatpos(int arr[],int index[][],int d){
        int size=arr.length;
        for(int [] x:index){
            int l = x[0];
            int r=x[1];
            for(int i=l;i<=r;i++){
                arr[i]=arr[i]+d;
            }
        }
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n];
		for(int i=0;i<n;i++){
		    arr[i]=sc.nextInt();
		}
		int row = sc.nextInt();
		int index[][] = new int [row][2];
		for(int i=0;i<row;i++){
		    index[i][0]=sc.nextInt();
		    index[i][1]=sc.nextInt();
		}
		int d = sc.nextInt();
		addatpos(arr,index,d);
		System.out.println(Arrays.toString(arr));
	}
}