import java.util.*;
public class Main {
    public static int Maxsum(int arr[],int div,int len){
        int dp[]=new int[div];
        Arrays.fill(dp,-1);
        dp[0]=0;
        for(int i=0;i<len;i++){
            int temp[]=new int[div];
            for(int j=0;j<div;j++){
                temp[j]=dp[j];
            }
            for(int j=0;j<div;j++){
                if(dp[j]!=-1){
                int sum=dp[j]+arr[i];
                int rem=sum%div;
                temp[rem]=Math.max(temp[rem],sum);
            }
            }
            dp=temp;
        }
        return dp[0];
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int m = sc.nextInt();
        int arr[] = new int[m];

        for(int i = 0; i < m; i++){
            arr[i] = sc.nextInt();
        }
        int n = sc.nextInt();
        System.out.println(Maxsum(arr,n,m));
    }
}