import java.util.*;
public class Main
{
    static String countsay(String a)
    {
        StringBuffer s=new StringBuffer();
        char prev=a.charAt(0);
        int c=1;
        for(int i=1;i<a.length();i++)
        {
            if(a.charAt(i)==prev)
            c++;
            else 
            {
                s.append(c).append(prev);
                c=1;
                prev=a.charAt(i);
            }
        }
        s.append(c).append(prev);
        return s.toString();
    }
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		String res="1";
		for(int i=2;i<=n;i++)
		res=countsay(res);
		
		System.out.println(res);
	}
}