
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		  int[] plays = {101, 102, 101, 103, 102, 101, 104, 103, 101};
		  Map<Integer,Integer> m = new LinkedHashMap<>();
		  for(int i=0;i<plays.length;i++){
		      if(m.containsKey(plays[i])){
		          m.put(plays[i],m.get(plays[i])+1);
		      }
		      else{
		          m.put(plays[i],1);
		      }
		  }
		 int maxcount=0;
		 int maxid=-1;
		 for(int x:m.keySet()){
		     if(m.get(x)>maxcount){
		         maxcount=m.get(x);
		         maxid=x;
		         
		     }
		 }
		 System.out.println(maxid+" "+maxcount);
		 for(int k:m.keySet()){
		     if(m.get(k)>1){
		         System.out.print(k+" ");
		     }
		 }
	}
}





Map in Java?

Map stores data in key–value pairs

Keys are unique

Values can be duplicate

Example:

Map<Integer, String> map = new HashMap<>();

Most Important Inbuilt Methods of Map
1. put(key, value)

 Used to insert data

map.put(1, "Apple");
map.put(2, "Banana");


If key already exists → value will be replaced.

2. get(key)

Used to get value using key

String val = map.get(1);
System.out.println(val);


Output:

Apple


If key not present → returns null.

3. containsKey(key)

Checks whether key exists

map.containsKey(2);


Returns:

true → key exists

false → key not exists

4. containsValue(value)

Checks whether value exists

map.containsValue("Apple");

5. remove(key)

 Removes entry using key

map.remove(1);


Key 1 and its value are deleted.

6. size()

 Returns number of entries

map.size();

7. isEmpty()

Checks whether map is empty

map.isEmpty();

8. keySet()

Returns all keys

Set<Integer> keys = map.keySet();
System.out.println(keys);

9. values()

Returns all values

Collection<String> values = map.values();
System.out.println(values);

10. entrySet()

 Returns key–value pairs

Set<Map.Entry<Integer, String>> entries = map.entrySet();


Used mainly for looping.

Example:

for (Map.Entry<Integer, String> e : map.entrySet()) {
    System.out.println(e.getKey() + " " + e.getValue());
}

11 clear()

 Removes all entries

map.clear();

12 replace(key, newValue)

 Replaces value for a key

map.replace(2, "Orange");