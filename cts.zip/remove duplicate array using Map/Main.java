import java.util.*;
public class Main
{
	public static void main(String[] args) {
	int arr[] = {1,2,3,4,1,2,3,4,1,2,3,4,5};
	Map<Integer,Integer> m = new LinkedHashMap<>();
	for(int i=0;i<arr.length;i++){
	    if(m.containsKey(arr[i])){
	        m.put(arr[i],m.get(arr[i])+1);
	    }
	    else{
	        m.put(arr[i],1);
	    }
	}
	for(int x:m.keySet()){
	    if(m.get(x)>1){
	        System.out.println(x);
	    }
	}
	}
}