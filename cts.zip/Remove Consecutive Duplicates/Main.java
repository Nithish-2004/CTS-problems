import java.util.*;
public class Main {
    public static String removeDuplicates(String s) {
        if (s==null||s.isEmpty()) {
            return s;
        }
        StringBuilder sb=new StringBuilder();
        for (int i=0;i<s.length();i++) {
            char currentChar=s.charAt(i);
            if(sb.length()==0||currentChar!=sb.charAt(sb.length()-1)) {
                sb.append(currentChar);
            }
        }
        return sb.toString();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        String result = removeDuplicates(input);
        System.out.println(result);
    }
}
