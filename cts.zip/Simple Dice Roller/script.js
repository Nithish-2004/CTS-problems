const rollBtn = document.getElementById("rollBtn");
const diceDisplay = document.getElementById("diceDisplay");

rollBtn.addEventListener("click", () => {
    diceDisplay.textContent = getRandomNumber();
});

function getRandomNumber() {
    // TODO: Return a random number between 1 and 6
    return Math.floor(Math.random()*6)+1;
}
