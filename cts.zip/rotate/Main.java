import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    String a=s.next();
	    String a1=s.next();
	    int f=0;
	    StringBuffer sb=new StringBuffer(a); 
	    for(int i=0;i<a.length();i++)
	    {
	        char c=sb.charAt(0);
	        sb.deleteCharAt(0);
	        sb.append(Character.toString(c));
	        if(a1.contentEquals(sb))
	        f=1;
	    }
		System.out.println(f==1?"yes":"no");
		
// 		String h=a+a;
// 		System.out.println(h.contains(a1));
		
	}

}