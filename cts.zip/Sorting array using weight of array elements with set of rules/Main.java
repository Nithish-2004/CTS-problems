import java.util.*;

public class Main {
    public static void sorting(int arr[]){
        int weight[]=new int[arr.length];
        for(int i=0;i<arr.length;i++){
            if(arr[i]%2==0){
                weight[i]+=3;
            }
            if(arr[i]%4==0 && arr[i]%6==0){
                weight[i]+=4;
            }
            for(int j=1;j<=arr[i]/2;j++){
                if(j*j==arr[i]){
                    weight[i]+=5;
                    break;
                }
            }
        }
            for(int i=0;i<arr.length-1;i++){
                int minindex=i;
                for(int j=i+1;j<arr.length;j++){
                    if(weight[j]>weight[minindex]){
                        minindex=j;
                    }
                }
                int temp=weight[i];
                weight[i]=weight[minindex];
                weight[minindex]=temp;
                
                 temp=arr[i];
                arr[i]=arr[minindex];
                arr[minindex]=temp;
                
                if(weight[i]==weight[minindex]){
                    if(arr[i]>arr[minindex]){
                        int temp1=arr[i];
                        arr[i]=arr[minindex];
                        arr[minindex]=temp1;
                    }
                }
            }
            System.out.println(Arrays.toString(arr));
            
        }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        sorting(arr);
        
    }
}