const weightInput = document.getElementById("weight");
const heightInput = document.getElementById("height");
const result = document.getElementById("result");
const button = document.getElementById("calculateBtn");

button.addEventListener("click", function () {
    const weight = weightInput.value;
    const height = heightInput.value;
    
    // TODO: calculate BMI and update result innerText
    const BMI=weight/(height*height);
    result.innerText=BMI;
});
