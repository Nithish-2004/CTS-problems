// Frequency Mapping
// A maintains a log of song plays throughout the day.

// Every time a user plays a song, the is recorded in a system log.

// At the end of the day, the analytics team wants to analyze the play patterns to improve song recommendations.

// You are given an integer array where each element represents a played by users during the day.
// Input:
//                       9
// int[] plays = {101, 102, 101, 103, 102, 101, 104, 103, 101};

// Song ID 101 → 4 plays
// Song ID 102 → 2 plays
// Song ID 103 → 2 plays
// Song ID 104 → 1 play

// Most played song: 101
// Songs played more than once: 101, 102, 103

import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for (int i = 0; i < n; i++) {
            arr[i]= sc.nextInt();
        }
        HashMap<Integer,Integer> m=new HashMap<>();
        ArrayList<Integer> l=new ArrayList<>();
        for (int i:arr)
        {
            m.put(i,m.getOrDefault(i,0)+1);d ,m
        }
        int max=Integer.MIN_VALUE;
        int h=0;
        for(Map.Entry<Integer,Integer> i:m.entrySet())
        {
            if(i.getValue()>max)
            {
                max=i.getValue();
                h=i.getKey();
            }
            if(i.getValue()>1)
            {
                l.add(i.getKey());
            }
        }
        System.out.println(h);
        System.out.println(l);
    }
}