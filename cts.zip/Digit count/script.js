const input = document.getElementById("textInput");
const digitCountEl = document.getElementById("digitCount");
const content = document.getElementById("text");

input.addEventListener("input", function () {

    /* TODO 1: Extract only digits from the input */

    /* TODO 2: Display the count of digits */

    /* TODO 3: Display extracted digits in the div */

});
