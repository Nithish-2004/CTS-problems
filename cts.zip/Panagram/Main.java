//You are given S1 and S2.

// You have to perform the following tasks:
// Clean both sentences by  
// Ignoring case differences
// Removing spaces
// Ignoring digits and special characters

// Check whether S1 and S2 are anagrams of each other.
// Check whether S1 is a pangram

// Input
// S1 = The quick brown fox jumps over the lazy dog!!!

// S2 = God over the lazy fox jumps quick brown the

// Output  
// Anagram: Yes

// Pangram: Yes

import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine().toLowerCase();
		int freq[]=new int[26];
		if(str.length()<26){
		    System.out.println("not panagram");
		    return;
		}
		for(int i=0;i<str.length();i++){
		    if(str.charAt(i)>='a' && str.charAt(i)<='z'){
		        int index=str.charAt(i)-'a';
		        freq[index]++;
		    }
		}
		for(int i=0;i<26;i++){
		    if(freq[i]==0){
		        System.out.println("no panagram");
		        return;
		    }
		}
		
		System.out.println("panagram");
	}
}