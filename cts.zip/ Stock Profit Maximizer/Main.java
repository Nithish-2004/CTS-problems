import java.util.*;
public class Main{
    public static int getMax(int len, int arr[]){
        int maxprofit=0;
        int minprice=Integer.MAX_VALUE; 
        for(int i = 0 ;i<len;i++){
            if(arr[i]<minprice){
                minprice=arr[i];
            }
            else if(arr[i]-minprice>maxprofit){
                maxprofit=arr[i]-minprice;
            }
        }
        return maxprofit;
    }
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       int size = sc.nextInt();
       int arr[]=new int[size];
       for(int i=0;i<size; i++) {
           arr[i]=sc.nextInt();
       }
       System.out.println(getMax(size,arr));
	}
}
