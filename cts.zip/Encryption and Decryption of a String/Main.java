// Problem Statement: Encryption and Decryption of a String

// You are given a string consisting of lowercase letters. Your task is to encrypt the string using the following rules:
// Each character in the string is replaced by its position in the alphabet (a = 1, b = 2, ..., z = 26).

// After converting to numbers:
// Characters at odd positions (1-based indexing) → add 1 to the number
// Characters at even positions → subtract 1 from the number
// The resulting sequence of numbers forms the encrypted message.
// You should also be able to decrypt a sequence of numbers using the reverse of the above rules to get back the original string.

// ✍️ Input Format
// The first line contains a string s (lowercase letters only).
// The second line contains the encrypted number sequence, space-separated (for decryption).

// 📤 Output Format
// For encryption, print the space-separated encrypted numbers.
// For decryption, print the original string.

// ❗ Constraints
// 1 ≤ length of string ≤ 100
// Input string contains only lowercase letters

// Sample Input:
// secure

// Sample Output 
// 20 4 4 20 19 4
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    String s=sc.nextLine();
	    String h="";
	    for(int i=0;i<s.length();i++){
	        if(i%2==0){
	            int k=s.charAt(i);
	            h=h+Math.abs(k+1-96);
	            h=h+" ";
	        }
	        else{
	            int k=s.charAt(i);
	            h=h+Math.abs(k-1-96);
	            h=h+" ";
	        }
	    }
	    System.out.println(h);
	}
}