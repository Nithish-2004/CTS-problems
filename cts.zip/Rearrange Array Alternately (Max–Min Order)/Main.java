// Problem Statement: Rearrange Array Alternately (Max–Min Order)

// You are given a sorted array of positive integers.
// Your task is to rearrange the array elements alternatively such that:

// The first element is the maximum value
// The second element is the minimum value
// The third element is the second maximum
// The fourth element is the second minimum, and so on

// ⚠️ Important Constraints:
// The rearrangement must be done in-place
// No extra space should be used
// You do not need to return anything, just modify the original array

// ✍️ Input Format
// The first line contains an integer n — the number of elements in the array
// The second line contains n space-separated positive integers, sorted in ascending order

// 📤 Output Format
// Print the modified array after rearranging the elements in max–min alternate order

// ❗ Constraints
// 1 ≤ n ≤ 10⁵
// 1 ≤ arr[i] ≤ 10⁹
// The array is initially sorted

// 🔄 Example 1
// Input: 6
// 1 2 3 4 5 6

// Output:
// 6 1 5 2 4 3

// 🔄 Example 2
// Input: 11
// 10 20 30 40 50 60 70 80 90 100 110

// Output:
// 110 10 100 20 90 30 80 40 70 50 60
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int[] arr=new int[n];
	    for(int i=0;i<n;i++){
	        arr[i]=sc.nextInt();
	    }
	    ArrayList<Integer> m=new ArrayList<>();
	    for(int i=0,j=arr.length-1;i<n/2&&j>=n/2;i++,j--){
	        m.add(arr[j]);
	        m.add(arr[i]);
	    }
	    if(arr.length%2!=0){
	        int h=arr[n/2];
	        m.add(h);
	    }
	    	System.out.println(m);

	}
}