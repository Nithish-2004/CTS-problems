import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;i++){
		    a[i]=sc.nextInt();
		}
		int vcount=0;
		int ci=0;
		while(ci>=0&&ci<n){
		    vcount++;
		    int jump=a[ci];
		    ci+=jump;
		}
		System.out.println(vcount);
	}
}