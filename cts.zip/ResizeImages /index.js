function resizeImages() {

    /* 
       TODO 5:
       Write JavaScript code to reset BOTH images
       Height  = 150px
       Width   = 150px
    */
    const img1=getElementById('image1');
    const img2=getElementById('image2');
    if(img1&&img2){
        img1.Height=150;
        img1.Width=150;
        img2.Height=150;
        img2.Width=150;
    }else{
        console.error("There is no image ");
    }
    
}
