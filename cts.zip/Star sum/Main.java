// 2.Star sum
// You are a marketing analyst tasked with identifying products to feature in a promotional campaign.
// Each product has a unique identifier M, and you use a metric called the Star Sum to evaluate these products.

// The star sum of a number is defined as the sum of all non-empty prefixes of M.

// For example,
// Star sum of 5043 = 5 + 50 + 504 + 5043 = 5602

// Given an integer N, your task is to find and return the count of values of M, such that:

// • M ≤ N
// • The star sum of M is greater than N

// Input Specification:

// input1: An integer value N

// Output Specification:

// Return an integer value representing the count of values of M such that M ≤ N and the star sum of M is greater than N.

// Example 1:

// Input:

// input1: 112

// Output:

// 10

// Explanation:

// We need to count how many values of M ≤ 112 have a star sum greater than 112.

// Star sum calculations:

// Star sum of 100 = 1 + 10 + 100 = 111 (not greater than 112)
// Star sum of 101 = 1 + 10 + 101 = 112 (not greater than 112)

// From 102 onwards, the star sum becomes greater than 112:

// Star sum of 102 = 113
// Star sum of 103 = 114
// Star sum of 104 = 115
// Star sum of 105 = 116
// Star sum of 106 = 117
// Star sum of 107 = 118
// Star sum of 108 = 119
// Star sum of 109 = 120
// Star sum of 110 = 122
// Star sum of 111 = 123
// Star sum of 112 = 124

// Valid values of M are:

// 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112

// Total valid values = 10

// Hence, 10 is returned as the output.... give the java code

import java.util.Scanner;
public class Main {
    public static long calculateStarSum(int M) {
        String s = String.valueOf(M);
        long starSumVal = 0;
        for (int i = 1; i <= s.length(); i++) {
            String prefix = s.substring(0, i);
            starSumVal += Long.parseLong(prefix);
        }
        return starSumVal;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int count = 0;
        for (int M = 1; M <= N; M++) {
            if (calculateStarSum(M) > N) {
                count++;
            }
        }
        System.out.println(count);
    }
}