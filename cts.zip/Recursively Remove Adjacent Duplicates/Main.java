import java.util.*;
public class Main {
    public static String removeDuplicates(String s) {
        StringBuilder sb = new StringBuilder(s);
        boolean foundDuplicate = true;
        while(foundDuplicate) {
            foundDuplicate=false;
            for (int i=0;i<sb.length()-1;i++) {
                if (sb.charAt(i)==sb.charAt(i+1)) {
                    sb.delete(i,i+2);
                    foundDuplicate = true;
                    i=-1; 
                    }
            }
        }
        return sb.toString();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        String result = removeDuplicates(input);
        System.out.println(result);
    }
}
