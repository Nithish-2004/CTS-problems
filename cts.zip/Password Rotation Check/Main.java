import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    String o=sc.nextLine();
	    String r=sc.nextLine();
	    if(o.length()==r.length()&&(o+o).contains(r)){
	        System.out.println("Yes");
	    }else{
	        System.out.println("No");
	    }
	    
	}
}