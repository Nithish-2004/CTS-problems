import java.util.*;
public class Main
{
	public static void main(String[] args) {
		  int[] plays = {101, 102, 101, 103, 102, 101, 104, 103, 101};
		  Map<Integer,Integer> m = new LinkedHashMap<>();
		  for(int i=0;i<plays.length;i++){
		      if(m.containsKey(plays[i])){
		          m.put(plays[i],m.get(plays[i])+1);
		      }
		      else{
		          m.put(plays[i],1);
		      }
		  }
		 int maxcount=0;
		 int maxid=-1;
		 for(int x:m.keySet()){
		     if(m.get(x)>maxcount){
		         maxcount=m.get(x);
		         maxid=x;
		         
		     }
		 }
		 System.out.println(maxid+" "+maxcount);
		 for(int k:m.keySet()){
		     if(m.get(k)>1){
		         System.out.print(k+" ");
		     }
		 }
	}
}