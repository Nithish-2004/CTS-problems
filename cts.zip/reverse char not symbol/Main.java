// You are given an array of integers and a number N.
// Your task is to find the maximum possible sum of elements from the array such that the sum is divisible by N.
// You may choose any subset of elements from the array (including all elements), but the resulting sum must be divisible by N.

// ✍️ Input Format
// The first line contains an integer M — the number of elements in the array
// The second line contains M space-separated integers
// The third line contains an integer N

// 📤 Output Format
// Print a single integer representing the maximum sum divisible by N

// ❗ Constraints
// 1 ≤ M ≤ 100
// 1 ≤ array[i] ≤ 10⁵
// 1 ≤ N ≤ 100

// 🔄 Example 1                                     🔄 Example 2
// Input: 4                                                  Input:6
// 10 20 40 70                                                     22 34 54 80 93 41
// 3                                                               5

// Output: 120                                              Output: 280


import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N=sc.nextInt();
        int[] arr=new int[N];
        for(int i=0;i<N;i++) {
            arr[i]=sc.nextInt();
        }
    
    }
}