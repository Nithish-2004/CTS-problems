// Q10)🔺 Problem: Count Possible Triangles

// You are given an array of positive integers representing the lengths of sticks.
// Your task is to find the number of possible triangles that can be formed using any three sticks.

// A triangle is valid if the sum of any two sides is greater than the third side.

// ✍️ Input Format
// An array of positive integers: arr[]

// 📤 Output Format
// A single integer — the number of possible triangles

// 🔄 Example 1
// Input:
// arr = {4, 6, 3, 7}

// Output:
// 3


// Explanation:
// The possible triangles are:
// {3, 4, 6}
// {4, 6, 7}
// {3, 6, 7}
// {3, 4, 7} is not possible because 3 + 4 ≤ 7

// 🔄 Example 2
// Input:
// arr = {10, 21, 22, 100, 101, 200, 300}

// Output:
// 6


// Explanation:
// The possible triangles are:
// {10, 21, 22}
// {21, 100, 101}
// {22, 100, 101}
// {10, 100, 101}
// {100, 101, 200}
// {101, 200, 300}
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new.Scanner(System.in);
		int 
		
	}
}