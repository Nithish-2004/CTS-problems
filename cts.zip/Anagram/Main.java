// You are given S1 and S2.

// You have to perform the following tasks:
// Clean both sentences by  
// Ignoring case differences
// Removing spaces
// Ignoring digits and special characters

// Check whether S1 and S2 are anagrams of each other.
// Check whether S1 is a pangram

// Input
// S1 = The quick brown fox jumps over the lazy dog!!!

// S2 = God over the lazy fox jumps quick brown the

// Output  
// Anagram: Yes

// Pangram: Yes
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str1 = sc.nextLine().toLowerCase();
		String str2 = sc.nextLine().toLowerCase();
		int freq[]=new int[26];
		for(int i=0;i<str1.length();i++){
		    if(str1.charAt(i)>='a' && str1.charAt(i)<='z'){
		        freq[str1.charAt(i)-'a']++;
		    }
		}
		for(int i=0;i<str2.length();i++){
		    if(str2.charAt(i)>='a' && str2.charAt(i)<='z'){
		        freq[str2.charAt(i)-'a']--;
		    }
		}
		for(int a:freq){
		    if(a!=0){
		        System.out.println("not anagram");
		        return;
		    }
		}
		System.out.println("Anagram");
		
	}
}