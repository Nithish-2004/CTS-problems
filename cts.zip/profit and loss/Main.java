import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int N=sc.nextInt();
	    int[] price=new int[N];
	    int[] span=new int[N];
	    for(int i=0;i<N;i++){
	    price[i]=sc.nextInt();
	    }
	    for (int i=0;i<N;i++) {
            span[i]=1; 
            for (int j=i-1;j>=0;j--) {
                if (price[j]<=price[i]) {
                    span[i]++;
                } else {
                    break;
                }
	}
}
        for (int i=0;i<N;i++) {
            System.out.print(span[i] + " ");
        }
    }
}
