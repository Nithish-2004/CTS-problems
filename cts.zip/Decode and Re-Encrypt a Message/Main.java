// Decode and Re-Encrypt a Message

// You are given a sequence of integers representing an encrypted message.
// Your task is to decrypt the message to obtain the original string and then
// encrypt it again using a different rule.

// 🔓 Decryption Rules

// Positions are 1-based

// Odd positions → subtract 1

// Even positions → subtract 1

// Convert the obtained numbers to letters
// (1 = a, 2 = b, …, 26 = z)

// 🔐 Encryption Rules

// Convert each letter to its alphabetical position

// Odd positions → add 2

// Even positions → add 1

// ✍️ Input Format

// A single line containing space-separated integers.

// 📤 Output Format

// A single line containing space-separated integers representing the
// new encrypted message.

// ❗Constraints

// 1 ≤ N ≤ 100

// All intermediate values after decryption will be between 1 and 26

// 📌 Example
// Sample Input
// 10 15 15 2 21 6

// 🔓 Decrypted Values
// 9 14 14 1 20 5

// 🔓 Decrypted String
// innate

// 🔐 Re-Encrypted Output
// 11 15 16 2 22 6

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String inputLine = sc.nextLine();
        String[] encryptedNumbersStr = inputLine.split(" ");
        int[] decryptedValues = new int[encryptedNumbersStr.length];
        for (int i = 0; i < encryptedNumbersStr.length; i++) {
            int encryptedValue = Integer.parseInt(encryptedNumbersStr[i]);
            decryptedValues[i] = encryptedValue - 1;
        }
        StringBuilder decryptedMessage = new StringBuilder();
        for (int value : decryptedValues) {
            char character = (char) ('a' + (value - 1));
            decryptedMessage.append(character);
        }
        StringBuilder reEncryptedOutput = new StringBuilder();
        for (int i = 0; i < decryptedMessage.length(); i++) {
            char character = decryptedMessage.charAt(i);
            int position = (character - 'a') + 1;
            int newEncryptedValue;
            if ((i + 1) % 2 != 0) {
                newEncryptedValue = position + 2;
            } else {
                newEncryptedValue = position + 1;
            }

            reEncryptedOutput.append(newEncryptedValue);
            if (i < decryptedMessage.length() - 1) {
                reEncryptedOutput.append(" ");
            }
        }
        System.out.println(reEncryptedOutput.toString());
    }
}
