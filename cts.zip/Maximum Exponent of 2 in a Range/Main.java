//  Problem: Maximum Exponent of 2 in a Range

// You are given two integers a and b (a < b).
// Your task is to find the number between a and b (inclusive) which has the maximum exponent of 2 in its prime factorization.
// The exponent of 2 of a number n is the largest integer k such that 2^k divides n.
// If multiple numbers have the same maximum exponent, return the smallest number among them.

// ✍️ Input Format
// Two integers a and b (a < b)

// 📤 Output Format
// A single integer — the number with maximum exponent of 2

// 🔄 Example 1
// Input
// 7
// 12

// Output : 8
import java.util.*;
public class Main{
    public static int pow(int x){
        int c=0;
        if(x==0){
            return 0;
        }
        while(x%2==0){
            x=x/2;
            c++;
        }
        return c;
    }
    
    
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int start = sc.nextInt();
		int end = sc.nextInt();
		int max=-1;
		int res=0;
		for(int i=start;i<=end;i++){
		    int power=pow(i);
		    if(power>max){
		        max=power;
		        res=i;
		    }
		}
		System.out.println(res);
	    
	}
}