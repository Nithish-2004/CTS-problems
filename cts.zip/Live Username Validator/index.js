const input = document.getElementById("username");
const message = document.getElementById("message");

input.addEventListener("input", function () {
    /* 1. Use .value to get the text, not the element itself */
    const usernameValue = input.value; 
    let regex=/^[A-Z a-z 0-9 _]+$/;
    /* 2. Perform the length check */
    if(usernameValue.length===0){
        message.innerText="";
        return;
    }
    if (usernameValue.length >= 6&&regex.test(usernameValue)) {
        message.innerText = "Valid Username";
        message.style.color = "green";
    } else {
        message.innerText = "Invalid Username";
        message.style.color = "red";
    }
});