import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;a[i++]=sc.nextInt());
		int c=0;
		  for(int i=0;i<n-1;i++){
		      if(a[i]%2!=0&&a[i+1]%2==0)
		      c++;
		  }
		System.out.println(c);
	}
}