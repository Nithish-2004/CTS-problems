// 1.Problem Title: Maximum People in a Lift
// Problem Understanding:

// You are given a lift (elevator) that can carry a maximum weight of X units.

// There are N people planning to use the lift, and the weights of each person are given in an array A.

// Your task is to figure out the maximum number of people who can use the lift together without exceeding its weight limit.

// Inputs:

// input1 (N): Number of people planning to use the lift

// input2 (X): Maximum weight capacity of the lift

// input3 (A): Array of size N representing the weights of each person

// Output:

// Return a single integer: the maximum number of people who can use the lift without exceeding the weight capacity X.

// Example:

// Input:

// N = 3

// X = 9

// A = [5, 1, 5]

// Explanation:

// If you take all three people: 5 + 1 + 5 = 11 → exceeds 9 ✅ Not allowed

// If you take two people:

// 5 + 1 = 6 → allowed

// 1 + 5 = 6 → allowed

// 5 + 5 = 10 → exceeds → not allowed

// Maximum people that can go together = 2

// Output:

// 2
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int N=sc.nextInt();
	    int A[]=new int[N];
	    for(int i=0;i<N;i++){
	        A[i]=sc.nextInt();
	    }
	    int X=sc.nextInt();
	    Arrays.sort(A);
	    int sum=0;
	    int count=0;
	    for(int i=0;i<N;i++){
	    if(sum+A[i]<=X){
	        sum=sum+A[i];
	        count++;
	    }else{
	        break;
	    }
	    }
	    System.out.println(count);
	}
}
